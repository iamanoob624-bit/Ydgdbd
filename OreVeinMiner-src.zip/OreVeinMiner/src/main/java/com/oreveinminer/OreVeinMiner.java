package com.oreveinminer;

import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.common.config.Configuration;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.event.FMLPreInitializationEvent;

@Mod(
        modid = OreVeinMiner.MODID,
        name = OreVeinMiner.NAME,
        version = OreVeinMiner.VERSION,
        acceptedMinecraftVersions = "[1.12.2]",
        acceptableRemoteVersions = "*" // all logic is server-side, clients don't need the mod
)
public class OreVeinMiner {

    public static final String MODID = "oreveinminer";
    public static final String NAME = "Ore Vein Miner";
    public static final String VERSION = "1.0.0";

    public static int maxBlocks;
    public static boolean mineDiagonals;
    public static boolean mineDifferentOres;
    public static boolean gatherDrops;
    public static boolean disableInCreative;

    @Mod.EventHandler
    public void preInit(FMLPreInitializationEvent event) {
        Configuration cfg = new Configuration(event.getSuggestedConfigurationFile());
        try {
            cfg.load();
            maxBlocks = cfg.getInt("maxBlocks", "general", 64, 1, 1024,
                    "Maximum number of extra ore blocks broken per vein (besides the one you mine).");
            mineDiagonals = cfg.getBoolean("mineDiagonals", "general", true,
                    "Also follow ores that only touch diagonally (26 neighbours instead of 6).");
            mineDifferentOres = cfg.getBoolean("mineDifferentOres", "general", false,
                    "If true, any connected ore breaks. If false, only the same ore type as the one you mined.");
            gatherDrops = cfg.getBoolean("gatherDrops", "general", true,
                    "Move all drops and XP to the block you actually mined.");
            disableInCreative = cfg.getBoolean("disableInCreative", "general", true,
                    "Do not vein mine while in creative mode.");
        } finally {
            if (cfg.hasChanged()) {
                cfg.save();
            }
        }

        MinecraftForge.EVENT_BUS.register(new VeinMiningHandler());
    }
}
