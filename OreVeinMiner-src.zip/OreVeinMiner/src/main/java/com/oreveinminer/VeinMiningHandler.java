package com.oreveinminer;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.regex.Pattern;

import net.minecraft.block.Block;
import net.minecraft.block.state.IBlockState;
import net.minecraft.entity.Entity;
import net.minecraft.entity.item.EntityItem;
import net.minecraft.entity.item.EntityXPOrb;
import net.minecraft.entity.player.EntityPlayerMP;
import net.minecraft.init.Blocks;
import net.minecraft.init.Items;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.util.ResourceLocation;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;
import net.minecraftforge.common.ForgeHooks;
import net.minecraftforge.common.util.FakePlayer;
import net.minecraftforge.event.entity.EntityJoinWorldEvent;
import net.minecraftforge.event.world.BlockEvent;
import net.minecraftforge.fml.common.eventhandler.EventPriority;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.oredict.OreDictionary;

public class VeinMiningHandler {

    /** Fallback for ores that have no item form or no ore dictionary entry (e.g. lit redstone ore). */
    private static final Pattern ORE_NAME = Pattern.compile("(^|[_.])ore([_.]|$)");

    /** True while we are breaking the extra blocks, so our own breaks don't trigger another vein. */
    private boolean mining = false;
    private final List<Entity> spawned = new ArrayList<>();

    @SubscribeEvent(priority = EventPriority.LOWEST)
    public void onBlockBreak(BlockEvent.BreakEvent event) {
        if (mining) return;

        World world = event.getWorld();
        if (world.isRemote) return;
        if (!(event.getPlayer() instanceof EntityPlayerMP) || event.getPlayer() instanceof FakePlayer) return;

        EntityPlayerMP player = (EntityPlayerMP) event.getPlayer();
        if (OreVeinMiner.disableInCreative && player.isCreative()) return;

        BlockPos start = event.getPos().toImmutable();
        IBlockState origin = event.getState();

        if (!isOre(origin)) return;
        // If the tool can't harvest the ore you're mining, don't destroy the rest of the vein for nothing.
        if (!ForgeHooks.canHarvestBlock(origin.getBlock(), player, world, start)) return;

        List<BlockPos> vein = findVein(world, start, origin);
        if (vein.isEmpty()) return;

        mining = true;
        try {
            for (BlockPos pos : vein) {
                ItemStack held = player.getHeldItemMainhand();
                // Keep 1 durability so the tool survives the block the player is actually breaking.
                if (!player.isCreative() && !held.isEmpty() && held.isItemStackDamageable()
                        && held.getMaxDamage() - held.getItemDamage() <= 1) {
                    break;
                }

                IBlockState state = world.getBlockState(pos);
                if (!matches(origin, state)) continue;
                if (!ForgeHooks.canHarvestBlock(state.getBlock(), player, world, pos)) continue;

                // Goes through the normal break path: other mods' protections, Fortune/Silk Touch,
                // tool damage, hunger and XP all apply.
                player.interactionManager.tryHarvestBlock(pos);
            }

            if (OreVeinMiner.gatherDrops) {
                for (Entity e : spawned) {
                    if (!e.isDead) {
                        e.setPosition(start.getX() + 0.5, start.getY() + 0.5, start.getZ() + 0.5);
                    }
                }
            }
        } finally {
            mining = false;
            spawned.clear();
        }
    }

    @SubscribeEvent
    public void onEntityJoin(EntityJoinWorldEvent event) {
        if (!mining || event.getWorld().isRemote) return;
        Entity e = event.getEntity();
        if (e instanceof EntityItem || e instanceof EntityXPOrb) {
            spawned.add(e);
        }
    }

    private List<BlockPos> findVein(World world, BlockPos start, IBlockState origin) {
        List<BlockPos> result = new ArrayList<>();
        Set<BlockPos> visited = new HashSet<>();
        ArrayDeque<BlockPos> queue = new ArrayDeque<>();
        visited.add(start);
        queue.add(start);

        final int max = OreVeinMiner.maxBlocks;
        final boolean diagonals = OreVeinMiner.mineDiagonals;

        scan:
        while (!queue.isEmpty()) {
            BlockPos cur = queue.poll();
            for (int dx = -1; dx <= 1; dx++) {
                for (int dy = -1; dy <= 1; dy++) {
                    for (int dz = -1; dz <= 1; dz++) {
                        if (dx == 0 && dy == 0 && dz == 0) continue;
                        if (!diagonals && Math.abs(dx) + Math.abs(dy) + Math.abs(dz) != 1) continue;

                        BlockPos next = cur.add(dx, dy, dz);
                        if (!visited.add(next)) continue;
                        if (!world.isBlockLoaded(next)) continue;
                        if (!matches(origin, world.getBlockState(next))) continue;

                        result.add(next);
                        queue.add(next);
                        if (result.size() >= max) break scan;
                    }
                }
            }
        }
        return result;
    }

    private static boolean matches(IBlockState origin, IBlockState other) {
        if (OreVeinMiner.mineDifferentOres) {
            return isOre(other);
        }
        return sameOre(origin, other);
    }

    private static boolean sameOre(IBlockState a, IBlockState b) {
        Block blockA = canonical(a.getBlock());
        Block blockB = canonical(b.getBlock());
        return blockA == blockB && a.getBlock().getMetaFromState(a) == b.getBlock().getMetaFromState(b);
    }

    /** Lit and unlit redstone ore count as the same ore. */
    private static Block canonical(Block block) {
        return block == Blocks.LIT_REDSTONE_ORE ? Blocks.REDSTONE_ORE : block;
    }

    private static boolean isOre(IBlockState state) {
        Block block = state.getBlock();

        Item item = Item.getItemFromBlock(block);
        if (item != Items.AIR) {
            try {
                ItemStack stack = new ItemStack(item, 1, block.getMetaFromState(state));
                for (int id : OreDictionary.getOreIDs(stack)) {
                    String name = OreDictionary.getOreName(id);
                    // "oreIron", "oreDiamond", "oreCopper", ...
                    if (name.length() > 3 && name.startsWith("ore") && Character.isUpperCase(name.charAt(3))) {
                        return true;
                    }
                }
            } catch (RuntimeException ignored) {
                // some modded blocks produce odd stacks; fall through to the name check
            }
        }

        ResourceLocation registryName = block.getRegistryName();
        return registryName != null && ORE_NAME.matcher(registryName.getResourcePath()).find();
    }
}
